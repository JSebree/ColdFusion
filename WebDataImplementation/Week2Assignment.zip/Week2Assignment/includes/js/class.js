function getarticle(e){
	window.location=window.location.pathname + '?content=' +  e;
}